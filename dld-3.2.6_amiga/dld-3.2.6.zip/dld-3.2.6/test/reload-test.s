#NO_APP
gcc2_compiled.:
___gnu_compiled_c:
.text
LC0:
	.ascii "Hello world! -- from reload-test\12\0"
	.even
.globl _main
_main:
	link a5,#0
	jbsr ___main
	pea LC0
	jbsr _printf
	addqw #4,sp
	moveq #0,d0
	jra L1
L1:
	unlk a5
	rts
.comm _end,4
