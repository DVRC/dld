#include <stdio.h>
#include <stdlib.h>
#include <ar.h>

static char buf[10240];

main(int argc, char **argv)
{
  FILE *exe, *arc;
  int id, r;

  if (argc != 3)
  {
    fprintf(stderr, "usage: ar2hunk <executable> <archive>\n");
    exit(2);
  }
  exe = fopen(argv[1], "r+");
  arc = fopen(argv[2], "r");
  if (!exe || !arc)
  {
    if (!exe)
      fprintf(stderr, "cannot open %s\n", argv[1]);
    if (!arc)
      fprintf(stderr, "cannot open %s\n", argv[2]);
    exit(2);
  }
  fseek(exe, -4, SEEK_END);
  fread(&id, 4, 1, exe);
  if (id != 0x3f2)
  {
    fprintf(stderr, "%s is malformed (no hunk_end found)\n", argv[1]);
    exit(1);
  }
  fread(buf, SARMAG, 1, arc);
  if (*((long *)buf) != 0x10107 && strncmp(buf, ARMAG))
  {
    fprintf(stderr, "%s is malformed (not an archive)\n", argv[2]);
    exit(1);
  }
  fseek(exe, -4, SEEK_END);
  id = 0x3f1;
  fwrite(&id, 4, 1, exe);
  fseek(arc, 0, SEEK_END);
  id = ftell(arc);
  id = (id + 3) / 4;
  fseek(arc, 0, SEEK_SET);
  fwrite(&id, 4, 1, exe);
  while (r = fread(buf, 1, 10240, arc))
  {
    r = (r + 3) & ~3;
    fwrite(buf, 1, r, exe);
  }
  id = 0x3f2;
  fwrite(&id, 4, 1, exe);
}
