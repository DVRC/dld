#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

static unsigned long get_num(int fd)
{
  unsigned long t;
  
  read(fd, &t, 4);
  return t;
}

static void skip(int fd, unsigned long t)
{
  lseek(fd, t * 4, SEEK_CUR);
}

static char *amiga_buf;
static int amiga_bufsize, amiga_bufptr, amiga_desc, amiga_read;

static void amiga_buf_init(int desc)
{
  amiga_desc = desc;
  if (amiga_buf == NULL)
  {
    amiga_bufsize = 10240;
    amiga_buf = (char *)malloc(amiga_bufsize);
  }
  amiga_read = read(amiga_desc, amiga_buf, amiga_bufsize);
  amiga_bufptr = 0;
}

static unsigned long fget_num(void)
{
  if (amiga_bufptr == amiga_bufsize)
  {
    amiga_read = read(amiga_desc, amiga_buf, amiga_bufsize);
    amiga_bufptr = 0;
  }
  amiga_bufptr += 4;
  return *((long *)(amiga_buf + amiga_bufptr - 4));
}

static void fread_string(char *buf, int size)
{
  while (amiga_bufptr + size > amiga_bufsize)
  {
    int diff = amiga_bufsize - amiga_bufptr;

    memcpy(buf, amiga_buf + amiga_bufptr, diff);
    buf += diff;
    size -= diff;
    amiga_read = read(amiga_desc, amiga_buf, amiga_bufsize);
    amiga_bufptr = 0;
  }
  memcpy(buf, amiga_buf + amiga_bufptr, size);
  amiga_bufptr += size;
}

static void amiga_buf_term(void)
{
  lseek(amiga_desc, amiga_bufptr - amiga_read, SEEK_CUR);
}

static void
amiga_read_file_symbols (desc)
register int desc;
{
  int t, f, l;
  int start, type, sdata, sbss;
  int name_size = 500;
  char *name;

  if (get_num(desc) != 0x03f3)
    exit(20);
  name = (char *)malloc(name_size);
  while (t = get_num(desc))
    skip(desc, t);
  get_num(desc);
  f = get_num(desc);
  l = get_num(desc);
  skip(desc, l - f + 1);
  while (l >= 0)
  {
    switch (t = get_num(desc))
    {
      case 0x03e9:      /* text */
        skip(desc, (t = get_num(desc)));
        break;
      case 0x03ea:      /* data */
        skip(desc, (sdata = get_num(desc)));
        break;
      case 0x03eb:      /* bss */
        sbss = get_num(desc) * 4;
        break;
      case 0x03e8:      /* name  */
      case 0x03e7:      /* unit  */
      case 0x03f1:      /* debug */
        skip(desc, get_num(desc));
        break;
      case 0x03ee:      /* reloc8  */
      case 0x03ed:      /* reloc16 */
      case 0x03ec:      /* reloc32 */
        while (t = get_num(desc))
          skip(desc, t + 1);
        break;
      case 0x03ef:      /* ext */
        while (t = get_num(desc))
          skip(desc, (t & 0xffffff) + 1);
        break;
      case 0x03f0:      /* symbols */
        amiga_buf_init(desc);
        while (t = fget_num())
        {
          while (t >= name_size)
          {
            char *buf = (char *)malloc(name_size * 2);
            
            free(name);
            name = buf;
            name_size *= 2;
          }
          fread_string(name, t * 4);
          name[t * 4] = 0;
          fget_num();
          printf("%s\n", name);
        }
        amiga_buf_term();
        break;
      case 0x03f2:      /* end */
        l--;
        break;
    }
  }
  free(name);
  if (amiga_buf)
    free(amiga_buf);
  amiga_buf = NULL;
}

main(int argc, char **argv)
{
  int fd;

  while (argv[1])
  {
    fd = open(argv[1], O_RDONLY);
    amiga_read_file_symbols(fd);
    close(fd);
    argv++;
  }
}
