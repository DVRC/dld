#include <stdio.h>
#include <dld.h>

#ifndef ADDLIBS
#define ADDLIBS "/gnu/lib/libgcc.a;/gnu/lib/libc.a"
#endif

static char *libs = ADDLIBS;

main(int argc, char **argv, char **env)
{
  char *p = libs;
  int done = 0;
  void (*func)(int, char **, char **);
  char *exe;
  char hack[2];

  hack[0] = 1;
  hack[1] = 0;
  exe = dld_find_executable(argv[0]);
  dld_init(exe);
  dld_create_reference("dld_main");
  strcat(exe, hack);
  if (dld_link(exe))
  {
    dld_perror("could not link in dld_main function");
    exit(1);
  }
  while (!done)
  {
    while (*p && *p != ';')
      p++;
    if (*p == '\0')
      done = 1;
    *p++ = '\0';
    if (dld_link(libs))
    {
      char buf[1000];

      strcpy(buf, "could not link in ");
      strcat(buf, libs);
      dld_perror(buf);
      exit(1);
    }
    libs = p;
  }

  func = (void (*)(int, char **, char **))dld_get_symbol("dld_main");
  if (func)
  {
    if (dld_function_executable_p("dld_main"))
    {
      func(argc, argv, env);
      exit(0);
    }
    else
    {
      char **symbols;
      int i;

      fprintf(stderr, "dld_main is not executable\n");
      symbols = dld_list_undefined_sym();
      if (dld_undefined_sym_count != 0)
        fprintf(stderr, "undefined symbols:\n");
      for (i = 0; i < dld_undefined_sym_count; i++) {
        fprintf(stderr, "%s\n", symbols[i]);
        free(symbols[i]);
      }
      free(symbols);
    }
  }
  else
    fprintf(stderr, "dld_main not found\n");
  exit(1);
}
